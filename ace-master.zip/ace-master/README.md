
Twitter bootstrap 3 admin template

see example http://ace.jeka.by/


Try:
- git clone git@github.com:bopoda/ace.git
- open ace/index.html in your desktop or mobile browser


Простой и многофункциональный Twitter bootstrap 3 шаблон для админки. Responsive дизайн.

Browsers:
- Internet Explorer 10
- Internet Explorer 11
- Internet Explorer 8
- Internet Explorer 9
- Latest Chrome
- Latest Firefox
- Latest Opera
- Latest Safari